package net.chekitech.jumiadeals;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;

public class ViewHolder extends RecyclerView.ViewHolder {

    public TextView title, company, location, contract;
    public ImageView image;
    public View mView;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);

        title = itemView.findViewById(R.id.rTitleTv);
        image = itemView.findViewById(R.id.rImageView);
        company = itemView.findViewById(R.id.rCompanyTv);
        location = itemView.findViewById(R.id.locationTv);
        contract = itemView.findViewById(R.id.contractTv);

        mView = itemView;

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mClickListener.onItemClick(view, getAdapterPosition());
            }
        });

        itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                mClickListener.onItemLongClick(view, getAdapterPosition());
                return true;
            }
        });

    }

    public void setDetails(Context ctx, String title, String company, String location, String money, String contract, String posting, String rdesc, String qdesc, String apply, String jlink, String klink, String visa, String image2, String image3, String image4, String image){

        TextView mTitleTv = mView.findViewById(R.id.rTitleTv);
        ImageView mImageIv = mView.findViewById(R.id.rImageView);
        TextView mDetailTv = mView.findViewById(R.id.rCompanyTv);
        TextView mlocationTv = mView.findViewById(R.id.locationTv);
        TextView mcontractTv = mView.findViewById(R.id.contractTv);

        mTitleTv.setText(title);
        Picasso.get().load(image).into(mImageIv);
        mDetailTv.setText(company);
        mlocationTv.setText(location);
        mcontractTv.setText(contract);

    }

    private ViewHolder.ClickListener mClickListener;

    public interface ClickListener{
        void onItemClick(View view, int position);
        void onItemLongClick(View view, int position);
    }

    public void setOnClickListener(ViewHolder.ClickListener clickListener){
        mClickListener = clickListener;
    }

}



